 #include <reg51.h>
#include <absacc.h>
#include <ctype.h>

unsigned int cnt1;
unsigned char cnt0;

#define leds P0
sbit G = P0^0;

unsigned char Disbuf[8];


void Disclear()
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		Disbuf[i] = 0x00;
	}
}


void Dischar(unsigned char x,unsigned char c,bit dot)
{
	code unsigned char tab[]=
	{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,
		0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
	unsigned char t;
		
	x &= 0x07;
	x = 7-x;
	if(c == '-')
	{
		t = 0x40;
	}
	else
	{
		t = toint(c);
		if (t<16)
		{
			t = tab[t];
		}
		else
		{
			t = 0x00;
		}
	}
	if(dot)
	{	t |= 0x80;}
	else
	{t &= 0x7F;}
	Disbuf[x] = t;
}


void Disstr(unsigned char x,unsigned char idata *s,unsigned char dotloc)
{
	unsigned char c;
	for(;;)
	{
		c = *s++;
		if (c == '\0') break;
		Dischar(x++,c,x == dotloc+1);
	}
}


void Sysinit()
{
	TMOD = 0x15;
	ET0 = 0;
	TR0 = 0;
	TH0 = 0x00;
	TL0 = 0x00;
	ET0 = 1;
	Disclear();
	EA = 1;
	ET1 = 1;
	TH1 = 0xfa;
	TL1 = 0x24;
	TR1 = 1;
	
}


void Longtostr(unsigned char idata *s,unsigned long c)
{
	code unsigned long tab[]={100000,10000,1000,100,10};
	unsigned char i,t;
	for(i=0;i<5;i++)
	{
		t = c/tab[i];
		*s++ = '0' + t;
		c -= t*tab[i];
	}
	*s++ = '0' + c;
	*s = '\0';
}


void T0INTSVC() interrupt 1
{
	cnt0++;
}


void T1INTSVC() interrupt 3
{
	
	unsigned long F;
	unsigned char idata s[6+1];
    TR1 = 0;
	TH1 = 0xfa;
	TL1 = 0x29;
	TR1 = 1;
	cnt1++;
	if(cnt1 > 1199) cnt1 = 0;
	TR0 = (cnt1 < 1000);
	
	
	leds = 0xFF;
	G = ~TR0;
	if(cnt1 == 1099)
	{
		F = cnt0;
		F <<= 8;
		F += TH0;
		F <<= 8;
		F += TL0;
	
		cnt0 = 0;
		TH0 = 0;
		TL0 = 0;

	
	   		
		Longtostr(s,F);
		Disstr(2,s,4);
	}
	
}


void main()
{
	code unsigned char com[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
	static unsigned char n = 0;
	Sysinit();
	for(;;)
	{
		XBYTE[0x7800] = 0xff;
	  XBYTE[0x7801] = ~Disbuf[n];
	  XBYTE[0x7800] = ~com[n];
	
	  n++;
	  n &= 0x07;
	}
}
	
	
