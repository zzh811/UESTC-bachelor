function varargout = scale_slow(varargin)
% SCALE_SLOW MATLAB code for scale_slow.fig
%      SCALE_SLOW, by itself, creates a new SCALE_SLOW or raises the existing
%      singleton*.
%
%      H = SCALE_SLOW returns the handle to a new SCALE_SLOW or the handle to
%      the existing singleton*.
%
%      SCALE_SLOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SCALE_SLOW.M with the given input arguments.
%
%      SCALE_SLOW('Property','Value',...) creates a new SCALE_SLOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before scale_slow_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to scale_slow_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help scale_slow

% Last Modified by GUIDE v2.5 02-Jun-2021 21:48:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @scale_slow_OpeningFcn, ...
                   'gui_OutputFcn',  @scale_slow_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before scale_slow is made visible.
function scale_slow_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to scale_slow (see VARARGIN)

% Choose default command line output for scale_slow
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes scale_slow wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = scale_slow_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in back.
function back_Callback(hObject, eventdata, handles)
close(scale_slow); 
set(scale_change,'Visible','on');
% hObject    handle to back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in RUN.
function RUN_Callback(hObject, eventdata, handles)
global filename pathname
pathall=strcat(pathname,filename);%���wav·��
[ori_sig,Fs] = audioread(pathall);
zd = length(ori_sig);
%ԭʼ�����źŵ�ʱ����ͼ
axes(handles.time1);
plot(ori_sig,'b');
title('ʱ����');
xlabel('ʱ�� s');ylabel('��ֵ y(t)');grid on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B=fft(ori_sig,zd);
mag=abs(B)/100;   
f=0:Fs/zd:Fs*(zd-1)/zd;
axes(handles.fre1);
plot(f,mag,'b');
axis([0 8000,0 500])
title('ԭʼ�����ź�Ƶ��ͼ');
xlabel('Ƶ�� Hz');ylabel('��ֵ mag');grid on;

sc_sig2 = resample(ori_sig,2*Fs,Fs);
axes(handles.time2);
plot(sc_sig2,'b');
title('ʱ����');
xlabel('ʱ�� s');ylabel('��ֵ y(t)');grid on;


zd2 = length(sc_sig2);
Fs2 = Fs/2;
B2=fft(sc_sig2,zd2);
mag2=abs(B2)/100;   
f2=0:Fs/zd2:Fs*(zd2-1)/zd2;
axes(handles.fre2);
plot(f2,mag2,'b');
axis([0 4000,0 500])
xlabel('Ƶ�� Hz');ylabel('��ֵ mag');grid on;
% hObject    handle to RUN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in PLAY.
function PLAY_Callback(hObject, eventdata, handles)
global filename pathname
pathall=strcat(pathname,filename);%���wav·��
[ori_sig,Fs] = audioread(pathall);
sc_sig2 = resample(ori_sig,2*Fs,Fs);
sound(sc_sig2,128000);
% hObject    handle to PLAY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in file_choose.
function file_choose_Callback(hObject, eventdata, handles)
global filename pathname
[filename,pathname]=uigetfile;
% hObject    handle to file_choose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
ha=axes('units','normalized','pos',[0 0 1 1]);
uistack(ha,'bottom');
ii=imread('background.jpeg');
image(ii);
colormap gray
set(ha,'handlevisibility','off','visible','on');
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
