function varargout = si_collect(varargin)
% SI_COLLECT MATLAB code for si_collect.fig
%      SI_COLLECT, by itself, creates a new SI_COLLECT or raises the existing
%      singleton*.
%
%      H = SI_COLLECT returns the handle to a new SI_COLLECT or the handle to
%      the existing singleton*.
%
%      SI_COLLECT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SI_COLLECT.M with the given input arguments.
%
%      SI_COLLECT('Property','Value',...) creates a new SI_COLLECT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before si_collect_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to si_collect_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help si_collect

% Last Modified by GUIDE v2.5 02-Jun-2021 21:48:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @si_collect_OpeningFcn, ...
                   'gui_OutputFcn',  @si_collect_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before si_collect is made visible.
function si_collect_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to si_collect (see VARARGIN)

% Choose default command line output for si_collect
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes si_collect wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = si_collect_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in back.
function back_Callback(hObject, eventdata, handles)
close(si_collect); 
set(main,'Visible','on');
% hObject    handle to back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
global b
a = get(handles.popupmenu1,'value');
b = a;
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in run.
function run_Callback(hObject, eventdata, handles)
global b
c = b;
scom = sprintf('COM%d',c);
obj = serial(scom);


obj.InputBufferSize = 10240000;%�������뻺�����Ĵ�С 
obj.OutputBufferSize = 10240000;%��������������Ĵ�С 
obj.Timeout = 15;%����һ��д����߶������������ʱ��Ϊ0.5sʱ�䵥λΪ�롣 
obj.BytesAvailableFcnMode = 'byte';% ���ö����ļ��ĸ�ʽΪ�����ơ� 

fclose(instrfind);   
fopen(obj);
 fwrite(obj,10240000) ;% 
 
data = fread(obj,10240000);% 
fclose(obj); % �رմ��ڶ���
delete(obj); % ɾ���ڴ��еĴ��ڶ���
[file1, path1]=uiputfile('*.wav');
filename1=[ path1, file1 ];
audiowrite(filename1,data,128000);
% hObject    handle to run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
ha=axes('units','normalized','pos',[0 0 1 1]);
uistack(ha,'bottom');
ii=imread('background.jpeg');
image(ii);
colormap gray
set(ha,'handlevisibility','off','visible','on');
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
